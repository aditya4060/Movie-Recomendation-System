<?php

$con = mysqli_connect("localhost","root","","movie_recommendation_system");


if(mysqli_connect_error())
{
    echo "Server Down";
}

?>

